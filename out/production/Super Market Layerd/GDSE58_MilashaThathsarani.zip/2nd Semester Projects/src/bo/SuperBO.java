package bo;

public interface SuperBO {
}
