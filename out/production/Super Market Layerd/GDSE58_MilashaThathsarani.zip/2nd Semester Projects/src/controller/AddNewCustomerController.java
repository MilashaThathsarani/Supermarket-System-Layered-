package controller;

import bo.BoFactory;
import bo.custom.CustomerBO;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import dto.CustomerDTO;

import java.sql.SQLException;
import java.util.ArrayList;

import static controller.MakeCustomerPlaceOrderController.customerDTOList;

public class AddNewCustomerController {
    private final CustomerBO customerBO = (CustomerBO) BoFactory.getBOFactory().getBO(BoFactory.BoTypes.CUSTOMER);
    public AnchorPane addNewCustomerContext;
    public JFXTextField txtCustomerTittle;
    public JFXTextField CustomerName;
    public JFXTextField txtCustomerAddress;
    public JFXTextField txtCity;
    public JFXTextField txtPostalCode;
    public JFXTextField txtProvince;
    public TableView<CustomerDTO> lblCustomerDetails;
    public TableColumn colId;
    public TableColumn colTittle;
    public TableColumn colName;
    public TableColumn colAddress;
    public TableColumn colCity;
    public TableColumn colProvince;
    public TableColumn colPostalCode;
    public TextField txtCustomerId;
    public JFXTextField txtScearchCustomer;

    static ArrayList<CustomerDTO> customerDTOArrayList = customerDTOList;

    public void initialize() throws SQLException, ClassNotFoundException {

        colId.setCellValueFactory(new PropertyValueFactory<>("custId"));
        colTittle.setCellValueFactory(new PropertyValueFactory<>("custTittle"));
        colName.setCellValueFactory(new PropertyValueFactory<>("custName"));
        colAddress.setCellValueFactory(new PropertyValueFactory<>("custAddress"));
        colCity.setCellValueFactory(new PropertyValueFactory<>("city"));
        colProvince.setCellValueFactory(new PropertyValueFactory<>("province"));
        colPostalCode.setCellValueFactory(new PropertyValueFactory<>("postalCode"));

        setItemsToTable(customerBO.getAll());

        setCustomerId();
    }

    public void closeStage(AnchorPane makeCustomerOrdersContext) {
        this.addNewCustomerContext = addNewCustomerContext;
    }

    private void setCustomerId() throws SQLException, ClassNotFoundException {
        txtCustomerId.setText(customerBO.getCustomerIds());
    }

    private void setItemsToTable(ArrayList<CustomerDTO> customerDTOS) {
        ObservableList<CustomerDTO> obList = FXCollections.observableArrayList();
        customerDTOS.forEach(e -> {
            obList.add(
                    new CustomerDTO(e.getCustId(),e.getCustTittle(),e.getCustName(),e.getCustAddress(),e.getCity(),e.getProvince(),e.getPostalCode()));
        });
        lblCustomerDetails.setItems(obList);
    }

    public void selectCustomer(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        String custId = txtScearchCustomer.getText();

        CustomerDTO customerDTO= customerBO.searchCustomer(custId);
        if (customerDTO==null) {
            new Alert(Alert.AlertType.WARNING, "Empty Result Set").show();
        } else {
            setData(customerDTO);
        }

    }

    private void setData(CustomerDTO c) {
        txtCustomerId.setText(c.getCustId());
        txtCustomerTittle.setText(c.getCustTittle());
        CustomerName.setText(c.getCustName());
        txtCustomerAddress.setText(c.getCustAddress());
        txtCity.setText(c.getCity());
        txtProvince.setText(c.getProvince());
        txtPostalCode.setText(c.getPostalCode());
    }

    public void addOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        String id= txtCustomerId.getText();
        String tittle = txtCustomerTittle.getText();
        String name = CustomerName.getText();
        String address = txtCustomerAddress.getText();
        String city = txtCity.getText();
        String province = txtProvince.getText();
        String postalCode = txtPostalCode.getText();

        CustomerDTO customerDTO = new CustomerDTO(id,tittle,name,address,city,province,postalCode);

            if (customerBO.addCustomer(customerDTO))
                new Alert(Alert.AlertType.CONFIRMATION, "Saved..").show();
            else
                new Alert(Alert.AlertType.WARNING, "Try Again..").show();

    }

    public void updateOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        String id= txtCustomerId.getText();
        String tittle = txtCustomerTittle.getText();
        String name = CustomerName.getText();
        String address = txtCustomerAddress.getText();
        String city = txtCity.getText();
        String province = txtProvince.getText();
        String postalCode = txtPostalCode.getText();

        CustomerDTO customerDTO = new CustomerDTO(id,tittle,name,address,city,province,postalCode);

            if (customerBO.updateCustomer(customerDTO)) {
                new Alert(Alert.AlertType.CONFIRMATION, "Updated..").show();
            } else {
                new Alert(Alert.AlertType.WARNING, "Try Again").show();

            }
    }

    public void DeleteOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        if (customerBO.deleteCustomer(txtCustomerId.getText())) {
            new Alert(Alert.AlertType.CONFIRMATION, "Deleted").show();
        } else {
            new Alert(Alert.AlertType.WARNING, "Try Again").show();
        }
    }

    public void searchOnAction(ActionEvent actionEvent) {
    }
}
