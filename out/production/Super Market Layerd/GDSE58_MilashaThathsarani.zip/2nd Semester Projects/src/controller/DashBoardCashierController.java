package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;

public class DashBoardCashierController {
    public AnchorPane cashierContext;

    private void loadUi(String filename) throws IOException {
        URL resource = getClass().getResource("../View/" + filename + ".fxml");
        Parent load = FXMLLoader.load(resource);
        cashierContext.getChildren().clear();
        cashierContext.getChildren().add(load);
    }


    public void manageOrderOnAction(ActionEvent actionEvent) throws IOException {
        loadUi("ManageOrders");
    }

    public void makeCustomerOnAction(ActionEvent actionEvent) throws IOException {
        loadUi("MakeCustomerOrders");
    }
}
