package controller;

import bo.BoFactory;
import bo.custom.ItemBO;
import com.jfoenix.controls.JFXTextField;
import dao.custom.impl.ItemDAOImpl;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import dto.ItemDTO;

import java.sql.SQLException;
import java.util.ArrayList;

import static java.lang.Integer.parseInt;

public class ItemController {
    private final ItemBO itemBO = (ItemBO) BoFactory.getBOFactory().getBO(BoFactory.BoTypes.ITEM);
    public TextField txtItemCode;
    public JFXTextField txtDescription;
    public JFXTextField txtPackSize;
    public JFXTextField txtQtyOnHand;
    public JFXTextField txtUnitPrice;
    public TableView<ItemDTO> tblItem;
    public TableColumn colItemCode;
    public TableColumn colDesccription;
    public TableColumn colPackSize;
    public TableColumn colQtyOnHand;
    public TableColumn colUnitPrice;

    public void initialize() throws SQLException, ClassNotFoundException {

        colItemCode.setCellValueFactory(new PropertyValueFactory<>("itemCode"));
        colDesccription.setCellValueFactory(new PropertyValueFactory<>("description"));
        colPackSize.setCellValueFactory(new PropertyValueFactory<>("packSize"));
        colQtyOnHand.setCellValueFactory(new PropertyValueFactory<>("qtyOnHand"));
        colUnitPrice.setCellValueFactory(new PropertyValueFactory<>("unitPrice"));

        setItemsToTable(itemBO.getAll());

        setItemId();
    }

    private void setItemsToTable(ArrayList<ItemDTO> itemDTOS) {
        ObservableList<ItemDTO> obList = FXCollections.observableArrayList();
        itemDTOS.forEach(e -> {
            obList.add(
                    new ItemDTO(e.getItemCode(), e.getDescription(), e.getPackSize(), e.getQtyOnHand(), (int) e.getUnitPrice()));
        });
        tblItem.setItems(obList);
    }

    private void setItemId() throws SQLException, ClassNotFoundException {
        txtItemCode.setText(itemBO.getItemIds());
    }

    public void selectItem(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        String itemId = txtItemCode.getText();

        ItemDTO itemDTO= itemBO.searchItem(itemId);
        if (itemDTO==null) {
            new Alert(Alert.AlertType.WARNING, "Empty Result Set").show();
        } else {
            setData(itemDTO);
        }
    }

    private void setData(ItemDTO itemDTO) {
        txtItemCode.setText(itemDTO.getItemCode());
        txtDescription.setText(itemDTO.getDescription());
        txtPackSize.setText(itemDTO.getPackSize());
        txtQtyOnHand.setText(String.valueOf(itemDTO.getQtyOnHand()));
        txtUnitPrice.setText(String.valueOf(itemDTO.getUnitPrice()));
    }

    public void addOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        String code = txtItemCode.getText();
        String description = txtDescription.getText();
        String packSize = txtPackSize.getText();
        double unitPrice = Double.parseDouble(txtUnitPrice.getText());
        int qtyOnHand = Integer.parseInt(txtQtyOnHand.getText());

        ItemDTO itemDTO = new ItemDTO(code,description,packSize,unitPrice,qtyOnHand);

            if (itemBO.addItem(itemDTO))
                new Alert(Alert.AlertType.CONFIRMATION, "Saved..").show();
            else
                new Alert(Alert.AlertType.WARNING, "Try Again..").show();

            setItemsToTable(new ItemDAOImpl().getAll());
    }

    public void updateOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        String code = txtItemCode.getText();
        String description = txtDescription.getText();
        String packSize = txtPackSize.getText();
        double unitPrice = Double.parseDouble(txtUnitPrice.getText());
        int qtyOnHand = Integer.parseInt(txtQtyOnHand.getText());

            ItemDTO itemDTO = new ItemDTO(code,description,packSize,unitPrice,qtyOnHand);

            if (itemBO.updateItem(itemDTO)) {
                new Alert(Alert.AlertType.CONFIRMATION, "Updated..").show();
                setItemsToTable(new ItemDAOImpl().getAll());
            } else {
                new Alert(Alert.AlertType.WARNING, "Try Again").show();

            }
    }

    public void deleteOnAction(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        if (itemBO.deleteItem(txtItemCode.getText())) {
            new Alert(Alert.AlertType.CONFIRMATION, "Deleted").show();
        } else {
            new Alert(Alert.AlertType.WARNING, "Try Again").show();
        }

        setItemsToTable(new ItemDAOImpl().getAll());
    }
}
