package dao;

public interface SuperDAO {
}
