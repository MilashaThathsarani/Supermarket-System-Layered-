package dao.custom;

import dao.SuperDAO;

public interface QueryDAO extends SuperDAO {
}
