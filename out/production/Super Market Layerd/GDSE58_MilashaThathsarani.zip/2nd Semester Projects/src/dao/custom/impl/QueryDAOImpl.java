package dao.custom.impl;

public class QueryDAOImpl {
}
