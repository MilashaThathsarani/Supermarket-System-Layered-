package dto;

public class CustomDTO {
}
